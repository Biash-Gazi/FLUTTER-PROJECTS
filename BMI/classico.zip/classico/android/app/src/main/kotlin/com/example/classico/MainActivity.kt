package com.example.classico

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
